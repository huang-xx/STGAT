## Requirements

* Python 3.7.0
* PyTorch 1.1
* adabound 0.0.5

## Explanation
This code generates the visualization of attention weights in the paper (Figure 8). Here are the results of zara1 dataset. The figures in the paper also include results of zara2 dataset.